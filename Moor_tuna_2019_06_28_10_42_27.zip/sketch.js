var trein
var wagons = [];
var aantalwagons = 10;
var speler
let img;
let img2;

var bars = [];
var amount = 0;

var punten = 0;
setInterval(walking_points,800);
setInterval(gold_spawner, 2000);
setInterval(gold_killer, 4000);

function end() {
  enemy.radius += 5;
}

function gold_killer(){
  for (i =0; i < bars.length; i++){
    goldbar = bars[i];
    goldbar.lives -= random(1,3);
    console.log(bars[i].lives);
  }
}

function gold_spawner() {
  goldbar = new gold (random(200,600),200,1, 1,30,20,3);
  bars.push(goldbar);
}

function walking_points(){
  punten += 5;
}
function preload() {  img = loadImage("https://media.discordapp.net/attachments/421772826257915935/590491062766927882/unknown.png");

img2 = loadImage("https://media.discordapp.net/attachments/421772826257915935/590506032309075979/New_Piskel_4_3.png");  

}

function setup() {
  createCanvas(800, 400);
  speler = new player(400,400,200,200,30,10,0,1);

  for (var i = 0; i < aantalwagons; i++){
    trein = new train (50,280,300,100,24,3, 30);
    wagons.push(trein); 
  }
    for (i = 0; i < amount; i++){
  goldbar = new gold (random(200,600),200,1, 1,30,20,5);
  bars.push(goldbar);
  //xPos, yPos, amount, speed,width,height, lives
  }
  enemy = new enemy(410,random(40,210),30,10,4);
}

function draw() {
  background(img);
  for (i = 0; i < bars.length; i++){
    goldbar = bars[i];
    goldbar.move();
    goldbar.display();
    goldbar.collision();
    
  }
  enemy.display();
  speler.display();
  speler.move();
  speler.gravity();
  speler.border()
  trein.move();
  trein.display();
  trein.collision();
  text(punten,20,20)
    
 
  
}
class player{
  constructor(plHeight, plWidth, xPos,yPos,radius, xSpeed, ySpeed,jump){
    this.yPos = yPos
    this.xPos = xPos
    this.radius = radius
    this.xSpeed = xSpeed
    this.ySpeed = ySpeed
    this.Height = plHeight
    this.Width = plWidth
    this.jump = true;
  }  
  display(){
    fill (0);
    image(img2, this.xPos, this.yPos - 120);
  
  }
  move(){
    if(this.yPos >= height - 35 && this.jump == false){this.jump = true}
    
    if (keyIsDown(UP_ARROW) && this.yPos >= this.radius && this.jump === true){
      this.jump = false;
      this.ySpeed -= 10;
      
    }
    if (keyIsDown(DOWN_ARROW) && this.yPos <= height - this.radius ){
      this.ySpeed += 0.4;
    }  
    if (keyIsDown(LEFT_ARROW) && this.xPos >= this.radius ){
      this.xPos -= this.xSpeed - 5;
    }  
    if (keyIsDown(RIGHT_ARROW) && this.xPos <= width - this.radius){
        this.xPos += this.xSpeed;
    }
  }
  gravity(){
    this.xPos -= 5;
    this.yPos += this.ySpeed;
    if(this.yPos > height) {
      this.ySpeed *= -0.1;
      this.yPos = height;
    }
    else{
      this.ySpeed += 0.3; 
    }
  
  }
  border(){
    if (this.yPos >= height - 35){
      this.ySpeed = 0;
    } 
    else if (this.yPos <= 0){
      this.yPos = 1;
      this.ySpeed = 0;
    } 
    else if (this.xPos >= width){
      this.xPos = width;
    } 
    else if (this.xPos <= 0){
      this.xPos = 1;
    }
  }
}
class train {
  constructor(xPos,yPos,width, height,speed,radius, xPos2){
    this.xPos = xPos;
    this.yPos = yPos;
    this.width = width;
    this.height = height;
    this.radius = radius;
    this.speed = speed;
    this.xPos2 = 30
    this.wagons = [];
    let wagon = new Wagon(this.xPos, this.yPos, this.width, this.height, 5);
    this.wagons.push(wagon);
    wagon = new Wagon(this.xPos + 400, this.yPos, this.width, this.height, 5);
    this.wagons.push(wagon);
    wagon = new Wagon(this.xPos + 800, this.yPos, this.width, this.height, 5);
    this.wagons.push(wagon);
    
  }
  
  display(){
    for (var i  = 0; i< this.wagons.length; i++){
        this.wagons[i].display();
    }
  }
  
  move(){
    for (var i  = 0; i< this.wagons.length; i++){
      this.wagons[i].move();
    }
  }
  collision (){
    for (var i = 0; i< this.wagons.length; i ++){
      this.wagons[i].collision();    
    }
    }
  
    
}


class Wagon {
  constructor(xPos, yPos, width, height,speed, radius,xPos2){
    this.xPos = xPos;
    this.yPos = yPos;
    this.width = width;
    this.height = height;
    this.speed = speed;
    this.radius = radius;
    this.xPosRaam1 = xPos + 30;
    this.xPosRaam2 = xPos + 130;
    this.xPosRaam3 = xPos + 230;
    this.xWiel1 = xPos + 20;
    this.yWiel = yPos + 90;
    this.xWiel2 = xPos + 280 ;
  }
  
  display(){
    strokeWeight(0);
    fill(255, 0, 0)
    rect (this.xPos , this.yPos, this.width, this.height);
    fill(0,255,255)
    rect (this.xPosRaam1,300,40,40)
    rect (this.xPosRaam2,300,40,40)
    rect (this.xPosRaam3,300,40,40)
    fill(0);
    ellipse(this.xWiel1, this.yWiel, 2*25, 2*25);
    ellipse(this.xWiel2, this.yWiel, 2* 25, 2* 25)

    
    
  }
  move(){
    if (this.xPos > width ){ 
        this.speed = -this.speed;
    }
    if(this.xPos < -200 ){
      this.xPos = 800;
  }
    this.xPos -= this.speed;
    
    if(this.xPosRaam1 < -200 || this.xPosRaam2 < -200 || this.xPosRaam3 < -200 || this.xWiel1 <- 200 || this.xWiel2 <- 200){
      this.xPosRaam1 = 800;
      this.xPosRaam2 = 1000;
      this.xPosRaam3 = 900;
      this.xWiel1 = 810;
      this.xWiel2 = 1050;
    }
    this.xPosRaam1 -= this.speed;
    this.xPosRaam2 -= this.speed;
    this.xPosRaam3 -= this.speed;
    this.xWiel1 -= this.speed;
    this.xWiel2 -= this.speed;
  }
  collision(){
    for (i = 0; i < wagons.length; i++){
        if (speler.yPos > wagons[i].yPos - speler.radius && speler.xPos < wagons[i].yPos +         wagons[i].width && speler.yPos < wagons[i].yPos + wagons[i].height){
          console.log();
          speler.yPos = this.yPos - speler.radius;
          speler.jump = true;
      }
      }
      
}
}
class gold{
  constructor(xPos,yPos, amount, speed,width,height,lives){
    this.xPos = xPos;
    this.yPos = yPos;
    this.amount = amount;
    this.speed = speed;
    this.width = width;
    this.height = height;
    this.lives = lives;
  }
  display(){
    for (i = 0; i < bars.length; i++){
    strokeWeight(0);
    fill(255, 255, 0);
    rect(bars[i].xPos,bars[i].yPos,30,10);
    
    if (goldbar.lives === 0){
        bars.splice(i,1);
  }
  }
  }
  move (){
    for (i = 0; i < bars.length; i++){
    bars[i].yPos += bars[i].speed;
    if (bars[i].yPos == 268){
      bars[i].speed = 0;
    }
    }
  }
  collision(){
    for (i = 0; i < bars.length; i++){
if (speler.xPos > bars[i].xPos -5 && speler.yPos > bars[i].yPos - 20 && speler.xPos < bars[i].xPos + bars[i].width && speler.yPos < bars[i].yPos + bars[i].width){
      strokeWeight(5);
      fill(255,100);
      rect(bars[i].xPos -10, bars[i].yPos - 170, 110,30);
      fill(0);
      text("press down arrow", bars[i].xPos -5, bars[i].yPos - 150)
      if (keyCode === DOWN_ARROW){
        bars.splice(i,1);
        punten += 20;
      }
    } 
    } 
  }
    
  
}
class enemy{
  contructor(x,y,w,h,r){
    this.xPos = x;
    this.yPos = y;
    this.width = w;
    this.height = h;
    this.radius = r;
  }
    display(){
    strokeWeight(1);
    fill(125);
   rect(this.xPos,this.yPos,this.width,this.height);
  }
  move(){
    this.xPos -= 3;
  }
  collision(){
    if(this.xPos < speler.xPos + speler.plWidth){
  strokeWeight(0);
  fill(0,255,0);    ellipse(400,200,this.radius*2,this.radius*2);
  setInterval(end(), 100);
    }
  }
}